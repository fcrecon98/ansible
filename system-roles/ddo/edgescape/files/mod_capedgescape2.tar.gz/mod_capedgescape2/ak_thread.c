static char fileIdent[]="$Id: //projects/edgescape/facilitator-2.5/akamai/facilitator/RELEASE/Unix/api/ak_thread.c#3 $";
/********************************************************************
*   Module:  ak_thread.c
*  Purpose:  Linux pthreads helper functions within Windows
********************************************************************/

/********************************************************************
* Copyright 1998-2001, Akamai Technologies, Inc.  This code and all
* associated documentation is proprietary to Akamai Technologies and
* is a trade secret.  All rights reserved.
********************************************************************/

#include "ak_thread.h"

#define TRUE 1

/****************************************************************
* Function:  pthread_once
*  Purpose:  Allow only first thread to execute init_routine, and
*         :   hold all others until it completes
*   Inputs:  
*         :  
*  Outputs:  0 on success, -1 on failure
********************************************************************/
int pthread_once(pthread_once_t *once_control, void (*init_routine)(void))
{
    
    while(100000 > *once_control)
    {
        if (0==InterlockedIncrement(once_control))
        {
            init_routine();
            *once_control=100001;
        }   /* if */
	else SleepEx(500, TRUE);;
    }   /* while */

    return(0);

}   /* pthread_once */
