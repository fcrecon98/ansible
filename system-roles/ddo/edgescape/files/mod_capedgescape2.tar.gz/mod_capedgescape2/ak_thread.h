/* $Id: //projects/edgescape/facilitator-2.5/akamai/facilitator/RELEASE/Unix/api/ak_thread.h#3 $ */

/********************************************************************
*   Module:  ak_thread.h
*  Purpose:  Portable threading model for unix pThreads and Windows NT
********************************************************************/

/********************************************************************
* Copyright 1998-2001, Akamai Technologies, Inc.  This code and all
* associated documentation is proprietary to Akamai Technologies and
* is a trade secret.  All rights reserved.
********************************************************************/

#ifndef AK_THREADS_H
#define AK_THREADS_H

    /********************************************************************
    * Linux/Unix/pThreads
    ********************************************************************/
#ifndef WIN32

#include <pthread.h>

    /********************************************************************
    * Windows NT
    ********************************************************************/
#else   /* ifndef WIN32 */

#ifndef _WINDOWS_
    #define _WIN32_WINNT 0x0400
    #include <windows.h>
#endif  /* _WINDOWS_ */
#include <process.h>

#ifndef EINVAL
#define EINVAL WSAEINVAL
#endif


typedef CRITICAL_SECTION pthread_mutex_t;
typedef DWORD pthread_t;

#define pthread_self GetCurrentThreadId
#define pthread_equal(x,y) ((x)==(y))

static int pthread_mutex_init(pthread_mutex_t *mutex, const void * attr)
{
    int ret_val;

    ret_val=0;
    if (NULL==attr)
	InitializeCriticalSection(mutex);
    else
	ret_val=EINVAL;

    return(ret_val);
}   /* pthread_mutex_init */

#define pthread_mutex_lock(x) EnterCriticalSection((x))
#define pthread_mutex_unlock(x) LeaveCriticalSection((x))

typedef unsigned (__stdcall *ms_thread)(void *);
//unsigned (__stdcall *) (void *)
static int pthread_create(pthread_t *thread, const void *attr, 
			  void *(*start_routine)(void *), void *arg)
{
    int ret_val;
    HANDLE handle;

    ret_val=0;

    if (NULL==attr)
    {
        handle=(HANDLE)_beginthreadex((void *)NULL, 0, 
          (ms_thread)start_routine, arg, 0, thread);

	/** we use thread id, kill off the handle now **/
	if (0!=handle)
	{
	    CloseHandle(handle);
	    ret_val=0;
	}   /* if */
        else
        {
	    ret_val=errno;
	    *thread=0;
	}   /* else */
    }   /* if */
    else ret_val=EINVAL;

    return(ret_val);

}   /* pthread_create */

     /* this eliminates later warnings as different .h files load
         in different orders */
#ifdef AK_THREAD_UNDEFINE
#undef EINVAL
#endif

#define pthread_detach(thread) (0)

typedef LONG pthread_once_t;
#define PTHREAD_ONCE_INIT -1
int pthread_once(pthread_once_t *once_control, void (*init_routine)(void));

#endif  /* WIN32 */


    /********************************************************************
    * Common declarations
    ********************************************************************/


#endif  /* AK_THREADS_H */
