#ifndef AKADATA_H
#define AKADATA_H

/* Modify these to your heart's content */
/* What should be returned as the default answer if there are problems               */
#define DEFAULT_ANSWER "default_answer=T\0country_code=JP\0default_source=client"

/* What machine is the facilitator engine runnning on?                               */
#define GLOBALHOST     "127.0.0.1"

/* What port is the engine listening on?                                             */
#define GLOBALPORT     "2001"

#ifdef HAVE_CONFIG_H
#  include "config.h"
#endif

#ifndef HAVE_CONFIG_H
/*  We now have to define everything without autoconf */
/* OS ids */
#if defined(sun) && (defined(__svr4__) || defined(SVR4)) && !defined(__solaris__)
#  define __solaris__
#endif
/* Pthreads */
#  if defined(__solaris__) || defined(__linux__) || defined(WIN32) || defined(__FreeBSD__)
#    define HAVE_PTHREAD_H
#  endif
/* unsigned info */
#  if defined(__solaris__)
#    define u_int32_t uint32_t
#    define u_int16_t uint16_t
#    define u_int8_t uint8_t
#endif
/* in_addr_t */
#  if defined(__solaris__) || defined(__linux__) || defined(__FreeBSD__)
#    define in_addr_t u_int32_t
#  endif
#endif


/* global constants */
#define  AKAMAI_OK            0
#define  AKAMAI_DEFAULT       1
#define  AKAMAI_GENERIC_ERROR 2
#define  AKAMAI_SMALL_BUFFER  3
#define  AKAMAI_TRY_AGAIN     4
#define  AKAMAI_PERMISSION_DENIED  5
#define  AKAMAI_NOT_FOUND     6


int akamai_ip_lookup(const in_addr_t *addr, char *buffer, size_t *len,
		     struct timeval *timeout);
int akamai_attr_get(const char *attr,
		    const char *buffer, const size_t buffer_len,
		    char **result);
char * get_aka_server(void);
int set_aka_server(char *facilip);
char * get_aka_port(void);
int set_aka_port(char *facilport);
int set_aka_server_and_port(char* facilip, char* facilport);
#endif


