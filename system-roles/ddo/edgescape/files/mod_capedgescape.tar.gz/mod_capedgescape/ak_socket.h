/* $Id: //projects/edgescape/facilitator-2.5/akamai/facilitator/RELEASE/Unix/api/ak_socket.h#3 $ */

/********************************************************************
*   Module:  ak_socket.h
*  Purpose:  Portable #include file for selecting between 
*         :   Linux/Unix network include files versus Windows equivalents
********************************************************************/

/********************************************************************
* Copyright 1998-2001, Akamai Technologies, Inc.  This code and all
* associated documentation is proprietary to Akamai Technologies and
* is a trade secret.  All rights reserved.
********************************************************************/

#ifndef AK_SOCKET_H
#define AK_SOCKET_H

#ifdef __cplusplus 
extern "C" {
#endif

    /********************************************************************
    * Common declarations/definitions
    ********************************************************************/
#define aks_listen listen
#define aks_bind bind
#define aks_accept accept
#define aks_connect connect
#define aks_socket socket


    /********************************************************************
    * Linux/Unix
    ********************************************************************/
#ifndef WIN32

#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/tcp.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/uio.h>
#include <sys/select.h>


typedef int socket_t;


#define AKSOCKET_INVALID (socket_t)(~0)
#define AKSOCKET_ERROR            (-1)

#define aks_close(socket) close((socket))

#define aks_read(sock, pos, len) read((sock), (pos), (len))
#define aks_write(sock, pos, len) write((sock), (pos), (len))
#define aks_select(countf, readf, writef, exceptf, timeout) \
    select((countf), (readf), (writef), (exceptf), (timeout))
#define aks_socket_init(x,y) do { } while(0)
#define aks_sendmsg(fd, msgsend, flags) sendmsg((fd), (msgsend), (flags))
#define ak_error_set(x) errno=(x)


    /********************************************************************
    * Windows NT
    ********************************************************************/
#else   /* ifndef WIN32 */

#ifndef _WINDOWS_
    #define _WIN32_WINNT 0x0400
    #include <windows.h>
#endif  /* _WINDOWS_ */

#include <WS2tcpip.h>
//#include "ms_win32/icmp.h"

#ifndef AK_SYSCALL_H
    #include "ak_syscall.h"
#endif

#include <Iphlpapi.h>

typedef SOCKET socket_t;
#define AKSOCKET_INVALID  INVALID_SOCKET
#define AKSOCKET_ERROR    SOCKET_ERROR

        /********************************************************************
        * #defines to duplicate unix error message defines
        ********************************************************************/

    /** translation of Windows Socket errors to Unix'isms **/
#ifdef _INC_ERRNO		/* errno.h has been loaded, stop and figure out why */
#error "errno.h has been included ... why?"
#else
	/* stop it from being included */
#define _INC_ERRNO
#endif	/* ifdef _INC_ERRNO */

	/** force all error number retrieval into the GetLastError world ... **/
#undef errno
#define errno WSAGetLastError()
#define aks_errno_set(x) WSASetLastError((x))

    /* The  socket  structure  address	is  outside  your address space. */
#define EFAULT  WSAEFAULT

    /* Address is already in use. */
#define EADDRINUSE WSAEADDRINUSE

    /* The socket is non-blocking and the connection cannot be completed 
        immediately. */
#define EINPROGRESS WSAEINPROGRESS

    /* The socket is non-blocking and a previous connection attempt has 
        not yet been completed. */
#define EALREADY WSAEALREADY

    /* Network is unreachable. */
#define ENETUNREACH WSAENETUNREACH

    /* The descriptor is not associated with a socket. */
#define ENOTSOCK WSAENOTSOCK

    /* The socket is already connected. */
#define EISCONN WSAEISCONN

    /* Connection refused at server. */
#define ECONNREFUSED WSAECONNREFUSED

    /* Timeout while attempting connection. */
#define ETIMEDOUT WSAETIMEDOUT

    /* Bad descriptor. */
#define EBADF WSAEBADF     

    /* A non blocked signal was caught. */
#define EINTR WSAEINTR

    /* The socket is associated with a connection-oriented protocol 
        and has  not  been  connected */
#define ENOTCONN WSAENOTCONN


#define ENOBUFS WSAENOBUFS
#define EAGAIN WSAEWOULDBLOCK
#define EWOULDBLOCK WSAEWOULDBLOCK
#define EHOSTUNREACH WSAEHOSTUNREACH
#define EHOSTDOWN WSAEHOSTDOWN
#define ENETDOWN WSAENETDOWN
#define EACCES WSAEACCES
#define EMSGSIZE WSAEMSGSIZE
#define ENOMEM WSA_NOT_ENOUGH_MEMORY
#ifndef EINVAL
    #define EINVAL WSAEINVAL
#endif
#define ENAMETOOLONG WSAENOBUFS
#define ENODATA WSAENOBUFS
#define ENOENT EBADF
#define ECOMM WSAENOTSOCK

    /** NOTICE:  I have blindly mapped these two error states, need 
        to devise a test scenario **/
#define EPIPE ERROR_BAD_PIPE   


#define HAVE_GETPROTOENT

	/** Win32StrErr uses FormatMessage */

#define strerror Win32StrErr

/* Type for length arguments in socket calls.  */
typedef unsigned int socklen_t;
//typedef struct in_addr in_addr_t;	/* wierd ... not sure why uint instead of struct */
typedef uint32_t in_addr_t;
typedef uint16_t in_port_t;
typedef void * __ptr_t;

  /** redefine Windows WSABUF to match unix iovec **/
struct iovec {
  u_long      iov_len;
  char FAR    *iov_base;
};



/* Structure describing messages sent by
   `sendmsg' and received by `recvmsg'.  */
struct msghdr
  {
    __ptr_t msg_name;           /* Address to send to/receive from.  */
    socklen_t msg_namelen;      /* Length of address data.  */

    struct iovec *msg_iov;      /* Vector of data to send/receive into.  */
    size_t msg_iovlen;          /* Number of elements in the vector.  */

    __ptr_t msg_control;        /* Ancillary data (eg BSD filedesc passing). */
    size_t msg_controllen;      /* Ancillary data buffer length.  */

    int msg_flags;              /* Flags on received message.  */
  };


        /********************************************************************
        * Portable function defines/declares
        ********************************************************************/
#define aks_close(socket) closesocket((socket))
#define aks_read(sock, pos, len) recv((sock), (pos), (len), 0)
#define aks_write(sock, pos, len) send((sock), (pos), (len), 0)
#define aks_socket_init(x,y) do { WSADATA w; WSAStartup(MAKEWORD(x,y), &w); } while(0)

        /********************************************************************
        * Custom Linux compatibility routines in ak_socket.c
        ********************************************************************/
int aks_select(int nfds, fd_set *readfds, fd_set *writefds, fd_set *exceptfds,
    struct timeval *timeout);
int aks_sendmsg (socket_t fd, const struct msghdr *message, int flags);

int inet_aton(const char *cp, struct in_addr *pin);

#if 0
    /* special functions from eth0.c */
int AkEthernameIp(const char * ethername, struct in_addr *ipaddr);
int AkEthernameMask(const char * ethername, struct in_addr *ipaddr);
int AkEthernameBCast(const char * ethername, struct in_addr *ipaddr);
int AkEthernameGateway(const char * ethername, struct in_addr *ipaddr);
int AkEthernameHWare(const char * ethername, unsigned char *ea);

int AkEthernameAddAddress(const char * ethername, IPAddr new_ip, IPAddr mask);
int AkEthernameDeleteAddress(const char * ethername, IPAddr old_ip);

PMIB_IFROW AkEthernameStats(const char * ethername);

PMIB_IPADDRTABLE AkSocketIpTable(int update);

#endif  /* 0 */

#endif  /* WIN32 */

    /********************************************************************
    * Common declarations/definitions
    ********************************************************************/
int aks_no_block(socket_t socket);

#ifdef __cplusplus 
}
#endif
#endif  /* AK_SOCKET_H */
