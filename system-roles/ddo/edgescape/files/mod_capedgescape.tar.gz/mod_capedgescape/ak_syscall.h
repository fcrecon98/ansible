/* $Id: //projects/edgescape/facilitator-2.5/akamai/facilitator/RELEASE/Unix/api/ak_syscall.h#3 $ */

/********************************************************************
*   Module:  ak_syscall.h
*  Purpose:  Portable #include file for selecting between 
*         :   Linux/Unix system library include files versus Windows equivalents
********************************************************************/

/********************************************************************
* Copyright 1998-2001, Akamai Technologies, Inc.  This code and all
* associated documentation is proprietary to Akamai Technologies and
* is a trade secret.  All rights reserved.
********************************************************************/

#ifndef AK_SYSCALL_H
#define AK_SYSCALL_H

/* Make this work with c++ */
#ifdef __cplusplus 
extern "C" {
#endif

    /********************************************************************
    * Common declarations/definitions
    ********************************************************************/
#include <sys/types.h>
#include <fcntl.h>

    /********************************************************************
    * Linux/Unix
    ********************************************************************/
#ifndef WIN32

#include <unistd.h>
#include <sys/time.h>
#include <sys/syslog.h>

#if 0
static void AkCorelimitSet(size_t x) 
{
	struct rlimit rl;

    getrlimit(RLIMIT_CORE, &rl);
    rl.rlim_cur = x;
    setrlimit(RLIMIT_CORE, &rl);

	return;

}	/* AkCorelimitSet */
#endif

#if 0
const char * process_name()
{
    static  char progname[100]={0};
    extern char *basname(char *);

    if(0==*progname)
     {
        char buf[256];
        FILE *in;
        int pid = getpid();
        snprintf(buf,256,"/proc/%d/cmdline",pid);
        buf[255] = 0;
        in = fopen(buf,"r");
        if( in && fgets(buf,255,in) ) {
            progname = strncpy(basename(buf),99);
	    progname[99]=0;
            fclose(in);
        } else {
            printf("WARN:: Unable to get program name");
            strcpy(progname,"UNKNOWN");
        }
    }
    return(progname);
}
#endif
    /********************************************************************
    * Windows NT
    ********************************************************************/
#else   /* ifndef WIN32 */

#ifndef _WINDOWS_
    #define _WIN32_WINNT 0x0400
    #include <windows.h>
#endif  /* _WINDOWS_ */

#include <process.h>

    /** posix.1g datatypes, needed int64_t so I went on and did all **/
typedef signed char int8_t;             /* also known as __int8 */
typedef unsigned char uint8_t;
typedef signed short int16_t;           /* also known as __int16 */
typedef unsigned short uint16_t;
typedef signed long int32_t;            /* also known as __int32 */
typedef unsigned long uint32_t;
typedef signed __int64 int64_t;
typedef unsigned __int64 uint64_t;

typedef uint32_t u_int32_t;				/* md5.h wants it this way ... */
typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned char u_char;

typedef int __ssize_t;
//typedef int ssize_t;			/* memory.h, string.h, etc have as unsigned */
typedef size_t ssize_t;


typedef long int __off_t;		/* Type of file sizes and offsets.  */
typedef __off_t off_t;

typedef DWORD pid_t;

    /** from Linux sys/time.h **/
/* Convenience macros for operations on timevals.
   The one in Winsock & Winsock2 is bad for >=.  */
#undef timercmp
#define	timercmp(a, b, CMP) 						      \
  (((a)->tv_sec == (b)->tv_sec) ? 					      \
   ((a)->tv_usec CMP (b)->tv_usec) : 					      \
   ((a)->tv_sec CMP (b)->tv_sec))

#define getpid GetCurrentProcessId

unsigned int sleep(unsigned int seconds);
int gettimeofday(struct timeval *tv, struct timezone *tz);
const char * process_name();

  //static void AkCorelimitSet(size_t x) {return;};

	/** TEMPORARY **/
  //#include <fcntl.h>

//#define LOG_ERR 0
//static void syslog(int priority, const char *message, ...) {return;};

  //int AkDaemonInit(int no_chdir, int no_close, int fork_flag);
  //int AkDaemonRunning(void);
  //void AkDaemonSetExcFilter();


#endif  /* WIN32 */

#ifdef __cplusplus 
}
#endif
#endif  /* AK_SYSCALL_H */
