/* $Id: //projects/edgescape/facilitator-2.5/akamai/facilitator/RELEASE/Unix/api/ak_clib.h#3 $ */

/********************************************************************
*   Module:  ak_clib.h
*  Purpose:  Portable #include file for selecting between 
*         :   Linux/Unix c library include files versus Windows equivalents
********************************************************************/

/********************************************************************
* Copyright 1998-2001, Akamai Technologies, Inc.  This code and all
* associated documentation is proprietary to Akamai Technologies and
* is a trade secret.  All rights reserved.
********************************************************************/

#ifndef AK_CLIB_H
#define AK_CLIB_H

#ifdef __cplusplus 
extern "C" {
#endif
    /********************************************************************
    * Common declarations/definitions
    ********************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <time.h>

    /********************************************************************
    * Linux/Unix
    ********************************************************************/
#ifndef WIN32

#include <errno.h>
#include <dirent.h>
#include <glob.h>


    /********************************************************************
    * Windows NT
    ********************************************************************/
#else   /* ifndef WIN32 */

#ifndef _WINDOWS_
    #define _WIN32_WINNT 0x0400
    #include <windows.h>
#endif  /* _WINDOWS_ */

  //#ifndef AK_SOCKET_H
  //#include "akamai/ak_socket.h"
  //#endif


#include <io.h>

#define __const const
#define NAME_MAX		4096
#define vsnprintf _vsnprintf
#define snprintf _snprintf
#define strcasecmp stricmp
#define strncasecmp strnicmp
#define random rand

  //#include "ms_win32/win32aklib.h"
  //#include "ms_win32/getopt.h"

int gettimeofday(struct timeval *tv, struct timezone *tz);
void bzero(void *s, int n);
void bcopy(const void *src, void *dst, size_t len);


char *sstrerr(int e);


#endif  /* WIN32 */

#ifdef __cplusplus 
}
#endif
#endif  /* AK_CLIB_H */
